﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using ViewDataDictionary.Models;

namespace ViewDataDictionary.Controllers
{
    public class HomeController : Controller
    {
        public ViewResult Index() 
        {
            ViewData["Keys"] = new List<string>()
            {
                "Employee_ID",
                "Employee_Name",
                "Employee_Blood_Group"
            };

            ViewData["Employee_ID"] = new List<string>()
            {
                "6197",
            };
            ViewData["Employee_Name"] = new List<string>()
            {
                "srishti kapoor",
            };

            ViewData["Employee_Blood_Group"] = new List<string>()
            {
                "O+",
            };

            return View();
        }

    }
}
